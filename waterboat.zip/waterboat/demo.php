<?php 
  include "header.php";
  ?> 
  <br>
  <br>
  <br>
  <br>
  
     
      <div class="container">
        <div class="row align-items-left text-left ">
            <h1 class="text-black ">Try mablei for fair billing and to save water</h1>
            <p class="text-white text-center">
              <span class="mx-2">/</span>
              <span>Contact Us</span>
            </p>
          </div>
        </div>
      
    

    
    <div class="site-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3 form-group">
                    <label for="fname">Your Name</label>
                    <input type="text" id="fname" class="form-control form-control-lg">
                </div>
                <div class="col-md-3 form-group">
                    <label for="lname">Email Address</label>
                    <input type="text" id="lname" class="form-control form-control-lg">
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 form-group">
                    <label for="eaddress">Mobile Number</label>
                    <input type="text" id="eaddress" class="form-control form-control-lg">
                </div>
                <div class="col-md-3 form-group">
                    <label for="tel">Your City</label>
                    <input type="text" id="tel" class="form-control form-control-lg">
                </div>
            </div>
			<div class="row">
                <div class="col-md-3 form-group"><br>
                    <label for="eaddress">Name Of Your Appartment/City</label>
                    <input type="text" id="eaddress" class="form-control form-control-lg">
                </div>
                <div class="col-md-3 form-group">
                    <label for="tel">Name Of Houses In Appartment/City</label>
                    <input type="text" id="tel" class="form-control form-control-lg">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="message">Your Requirements</label>
                    <textarea name="" id="message" cols="30" rows="10" class="form-control"></textarea>
                </div>
            </div>

            <div class="row">
                <div class="col-6">
                    <input type="submit" value="Request Demo" class="btn btn-primary rounded-0 px-3 px-5">
                </div>
            </div>
        </div>
    </div>

<p>Mablei is automatic water management & billing system designed for apartments & high rise buildings

Mablei integrated water management solution includes smart water meters, flexible billing engine, value added services such as plumbing and post sales customer support

Please provide your details in the form and we’ll contact you as soon as possible to walk you through mablei integrated water management solution and its benefits.</p>
  
  
  
  
  
  <?php 
  include "footer.php";
  ?>
  
   